=========
Changelog
=========

Version 0.9.0
===========

- Implemented variable substitution (VariableFixer class).
- Implemented comment substitution (CommentFixer class).
- Added CLI "lance".
- Added rudimentary testing for both fixers classes.

Version 0.9.1
===========

- variable names now contain animal sounds.
- README.md is prototyped.


Version 0.9.2
===========

- Added some animal sounds.
- README.md is now drafted
- Uploading to test-PyPi
- Renaming package to py-lancer to avoid clash in PyPi


Version 1.0.0 (TODO)
===========

- test PyPi is working as expected.
- ready for release



